package com.logikas.gwt.examples.client.view;

import com.google.gwt.user.client.ui.IsWidget;

public interface PersonView extends IsWidget {

}
