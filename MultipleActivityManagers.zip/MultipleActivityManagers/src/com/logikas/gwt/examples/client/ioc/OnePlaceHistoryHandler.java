package com.logikas.gwt.examples.client.ioc;

import com.google.gwt.place.shared.PlaceHistoryHandler;
import com.google.gwt.place.shared.PlaceHistoryMapper;

public class OnePlaceHistoryHandler extends PlaceHistoryHandler{

	public OnePlaceHistoryHandler(PlaceHistoryMapper mapper) {
		super(mapper);
	}

}
