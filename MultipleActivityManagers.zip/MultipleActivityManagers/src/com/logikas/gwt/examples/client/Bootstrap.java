package com.logikas.gwt.examples.client;
/**
 * @author Cristian Rinaldi
 */
public interface Bootstrap{

    void start();
    
}
